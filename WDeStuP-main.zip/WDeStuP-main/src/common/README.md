# Common Files
This directory is for the shared files between different components (such as plugins, visualizers, etc) and is available in requirejs under your webgme app name (WDeStuP)
