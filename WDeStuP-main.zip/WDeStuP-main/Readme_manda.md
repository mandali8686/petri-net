Mini Project: Petri net design studio

This repository include a petri net design studio that was added to WebGME platform. Petri net is a directed bipartite graph modeling language. The two node types in the Petri net model are place (circle), and transition (square). The arcs are navigated from a place node to a transition nodes, or from a transition node to a place node.
Petri net design studio provides a graphical user interface that allows users to easily create and edit Petri net models. It also includes a simulation engine that can be used to test and analyze the behavior of the model under different scenarios. This can help users understand how the system will behave in different situations and identify potential problems or bottlenecks. 
In application, Petri net can be used in many scenarios, especially in simulation, design and analyze complex systems. It can be used to represent state machines with place represent state and transition as transition between states. It can also be used to represent data flow. Petri net can map the flow of data by assigning name to the place node and assign operation characters to form a calculation representation. Petri net can also be used for communication protocol representation, parallelism representation, and formal language recognition.
In addition to its simulation capabilities, Petri net design studio also offers a number of analysis tools that can be used to perform formal verification of Petri net models. These tools can check for properties such as deadlocks, livelocks, and reachability, and can also be used to compute the maximum or minimum number of tokens that can be present in a given place at a given time. 

Installation process

 This installation process works for my MacOS m1.
Clone this repository by command line: git clone https://github.com/mandali8686/petri-net.git
Enter the cloned directory by command line: cd petri-net
NVM need to be installed first. If have NVM installed, run the command line: nvm install 18 && nvm use 18
Install npm by: npm install -g npm@8.15.1
Install MongoDB by: brew install mongodb-community@4.4
Install webgme-cli by: nom install -g webgme-cli
Start npm by: npm start
Start webgme by: webgme start
Wait until terminal shows “Server is listening”, open a web browser and navigate to 127.0.0.1:8080

In this domain, the Petri net seed should show when you try to create a new project and choose from an existing seed. Select the petri net seed to start modeling. The features including Petri net, Petri net container, Place, and Transition should be available for guest in the left toolbar. 




Reference: 
https://link.springer.com/referenceworkentry/10.1007/978-0-387-09766-4_134#:~:text=Definition,to%20transitions%20or%20vice%20versa.
https://webgme.readthedocs.io/en/latest/index.html
https://github.com/webgme/webgme-cli
https://github.com/rpicard92/colored-petri-net-design-studio
https://github.com/webgme/webgme/blob/master/config/README.md